# hello_chat_gpt
A program with a command line way to chat with ChatGPT. Use gpt-3.5-turbo Model Api.
